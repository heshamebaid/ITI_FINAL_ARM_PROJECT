
#ifndef HLCD_PRIVATE_H_
#define HLCD_PRIVATE_H_


#define DDRAM_OFFSET 		0x40


#endif /* HLCD_PRIVATE_H_ */

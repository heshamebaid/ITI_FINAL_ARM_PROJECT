
#ifndef EXTI_CONFIGURATION_H_
#define EXTI_CONFIGURATION_H_


#define MEXTI_NUMBER			3


#endif /* EXTI_CONFIGURATION_H_ */


#ifndef MNVIC_CONFIG_H_
#define MNVIC_CONFIG_H_

#endif /* MNVIC_CONFIG_H_ */

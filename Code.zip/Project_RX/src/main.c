
/********************LIB****************************/
#include <LIB/BIT_MATH.h>
#include <LIB/STD_Types.h>

/*******************MCAL****************************/
#include <MCAL/RCC/MRCC_Interface.h>
#include <MCAL/GPIO/MGPIO_Interface.h>
#include <MCAL/NVIC/MNVIC_Interface.h>
#include <MCAL/USART/MUSART_Interface.h>


/************* functions Prototyping********************/
void handler_USART(void);
void SYSTEM_INIT(void);
void PINS_Config(void);
void USART_Config(void);
void BUTTONS_Config(void);
/*****************Variable**************************/
u8 Global_u8RX ;
// Define variables to store the status of each feature
u8 mainDoorStatus;
u8 cameraSystemStatus;
u8 garageDoorStatus;

/**********************LED MATREX***************************/
#define SIZE       64
#define	SIZE_GAR   80
#define SIZE_CAM  96

u8 Main[SIZE][8] = {

		{255, 2, 4, 8, 4, 2, 255, 0},//M
		    {2, 4, 8, 4, 2, 255, 0, 0},
		    {4, 8, 4, 2, 255, 0, 0, 0},
		    {8, 4, 2, 255, 0, 0, 0, 0},
		    {4, 2, 255, 0, 0, 0, 0, 0},
		    {2, 255, 0, 0, 0, 0, 0, 0},
		    {255, 0, 0, 0, 0, 0, 0, 0},
		    {0, 0, 0,0,0,0,0,0},


		    {0, 252, 36, 36, 36, 252, 0, 0},//A
		    {252, 36, 36, 36, 252, 0, 0, 0},
		    {36, 36, 36, 252, 0, 0, 0, 0},
		    {36, 36, 252, 0, 0, 0, 0, 0},
		    {36, 252, 0, 0, 0, 0, 0, 0},
		    {252, 0, 0, 0, 0, 0, 0, 0},
		    {0, 0, 0, 0, 0, 0, 0, 0},
		    {0, 0, 0, 0, 0, 0, 0, 0},


	{129, 129, 129, 255, 129, 129, 129, 0}, //I
	    {129, 129, 255, 129, 129, 129, 0, 0},
	    {129, 255, 129, 129, 129, 0, 0, 0},
	    {255, 129, 129, 129, 0, 0, 0, 0},
	    {129, 129, 129, 0, 0, 0, 0, 0},
	    {129, 129, 0, 0, 0, 0, 0, 0},
	    {129, 0, 0, 0, 0, 0, 0, 0},
	    {0,0,0,0,0,0,0,0},
		{255, 2, 4, 8, 16, 32, 255, 0},//N
		    {2, 4, 8, 16, 32, 255, 0, 0},
		    {4, 8, 16, 32, 255, 0, 0, 0},
		    {8, 16, 32, 255, 0, 0, 0, 0},
		    {16, 32, 255, 0, 0, 0, 0, 0},
		    {32, 255, 0, 0, 0, 0, 0, 0},
		    {255, 0, 0, 0, 0, 0, 0, 0},
		    {0, 0, 0,0,0,0,0,0},

	{255, 129, 129, 129, 129, 129, 126, 0}, //D
    { 129, 129, 129, 129, 129, 126, 0, 0},
    { 129, 129, 129, 129, 126, 0, 0, 0},
    {129, 129, 129, 126, 0, 0, 0, 0},
    {129, 129, 126, 0, 0, 0, 0, 0},
    { 129, 126, 0, 0, 0, 0, 0, 0},
    { 126, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

	{126, 129, 129, 129, 129, 129, 126, 0},//O
	    {129, 129, 129, 129, 129, 126, 0, 0},
	    {129, 129, 129, 129, 126, 0, 0, 0},
	    {129, 129, 129, 126, 0, 0, 0, 0},
	    {129, 129, 126, 0, 0, 0, 0, 0},
	    {129, 126, 0, 0, 0, 0, 0, 0},
	    {126, 0, 0, 0, 0, 0, 0, 0},
	    {0,0,0,0,0,0,0,0},

		{126, 129, 129, 129, 129, 129, 126, 0},//O
		    {129, 129, 129, 129, 129, 126, 0, 0},
		    {129, 129, 129, 129, 126, 0, 0, 0},
		    {129, 129, 129, 126, 0, 0, 0, 0},
		    {129, 129, 126, 0, 0, 0, 0, 0},
		    {129, 126, 0, 0, 0, 0, 0, 0},
		    {126, 0, 0, 0, 0, 0, 0, 0},
		    {0,0,0,0,0,0,0,0},

	{255, 9, 9, 9, 57, 255, 199, 0},//R
    {9, 9, 9, 57, 255, 199, 0, 0},
    {9, 9, 57, 255, 199, 0, 0, 0},
    {9, 57, 255, 199, 0, 0, 0, 0},
    {57, 255, 199, 0, 0, 0, 0, 0},
    {255, 199, 0, 0, 0, 0, 0, 0},
    {199, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},
};


u8 Garage[SIZE_GAR][8] = {

{255, 129, 129, 129, 137, 249, 8, 0},//G
    {129, 129, 129, 137, 249, 8, 0, 0},
    {129, 129, 137, 249, 8, 0, 0, 0},
    {129, 137, 249, 8, 0, 0, 0, 0},
    {137, 249, 8, 0, 0, 0, 0, 0},
    {249, 8, 0, 0, 0, 0, 0, 0},
    {8, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},



	    {0, 252, 36, 36, 36, 252, 0, 0},//A
	    {252, 36, 36, 36, 252, 0, 0, 0},
	    {36, 36, 36, 252, 0, 0, 0, 0},
	    {36, 36, 252, 0, 0, 0, 0, 0},
	    {36, 252, 0, 0, 0, 0, 0, 0},
	    {252, 0, 0, 0, 0, 0, 0, 0},
	    {0, 0, 0, 0, 0, 0, 0, 0},
	    {0, 0, 0, 0, 0, 0, 0, 0},


	{255, 9, 9, 9, 57, 255, 199, 0},//R
    {9, 9, 9, 57, 255, 199, 0, 0},
    {9, 9, 57, 255, 199, 0, 0, 0},
    {9, 57, 255, 199, 0, 0, 0, 0},
    {57, 255, 199, 0, 0, 0, 0, 0},
    {255, 199, 0, 0, 0, 0, 0, 0},
    {199, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

	{254, 17, 17, 17, 17, 17, 254, 0},         		//A
	{ 17, 17, 17, 17, 17, 254, 0,0},
    {17, 17, 17, 17, 254, 0, 0, 0},
    { 17, 17, 17, 254, 0, 0, 0, 0},
    { 17, 17, 254, 0, 0, 0, 0, 0},
    { 17, 254, 0, 0, 0, 0, 0,0},
    { 254, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0}     ,

	{255, 129, 129, 129, 137, 249, 8, 0},//G
    {129, 129, 129, 137, 249, 8, 0, 0},
    {129, 129, 137, 249, 8, 0, 0, 0},
    {129, 137, 249, 8, 0, 0, 0, 0},
    {137, 249, 8, 0, 0, 0, 0, 0},
    {249, 8, 0, 0, 0, 0, 0, 0},
    {8, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

	{255, 145, 145, 145, 145, 145, 145, 145},//E
    {145, 145, 145, 145, 145, 145, 145, 0},
    {145, 145, 145, 145, 145, 145, 0, 0},
    {145, 145, 145, 145, 145, 0, 0, 0},
    {145, 145, 145, 145, 0, 0, 0, 0},
    {145, 145, 145, 0, 0, 0, 0, 0},
    {145, 145, 0, 0, 0, 0, 0, 0},
    {145, 0, 0, 0, 0, 0, 0, 0},

	{255, 129, 129, 129, 129, 129, 126, 0}, //D
    { 129, 129, 129, 129, 129, 126, 0, 0},
    { 129, 129, 129, 129, 126, 0, 0, 0},
    {129, 129, 129, 126, 0, 0, 0, 0},
    {129, 129, 126, 0, 0, 0, 0, 0},
    { 129, 126, 0, 0, 0, 0, 0, 0},
    { 126, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

	{126, 129, 129, 129, 129, 129, 126, 0},//O
	    {129, 129, 129, 129, 129, 126, 0, 0},
	    {129, 129, 129, 129, 126, 0, 0, 0},
	    {129, 129, 129, 126, 0, 0, 0, 0},
	    {129, 129, 126, 0, 0, 0, 0, 0},
	    {129, 126, 0, 0, 0, 0, 0, 0},
	    {126, 0, 0, 0, 0, 0, 0, 0},
	    {0,0,0,0,0,0,0,0},


		{126, 129, 129, 129, 129, 129, 126, 0},//O
		    {129, 129, 129, 129, 129, 126, 0, 0},
		    {129, 129, 129, 129, 126, 0, 0, 0},
		    {129, 129, 129, 126, 0, 0, 0, 0},
		    {129, 129, 126, 0, 0, 0, 0, 0},
		    {129, 126, 0, 0, 0, 0, 0, 0},
		    {126, 0, 0, 0, 0, 0, 0, 0},
		    {0,0,0,0,0,0,0,0},

	{255, 9, 9, 9, 57, 255, 199, 0},//R
    {9, 9, 9, 57, 255, 199, 0, 0},
    {9, 9, 57, 255, 199, 0, 0, 0},
    {9, 57, 255, 199, 0, 0, 0, 0},
    {57, 255, 199, 0, 0, 0, 0, 0},
    {255, 199, 0, 0, 0, 0, 0, 0},
    {199, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},
};

u8 Cam[SIZE_CAM][8] = {
    {126, 129, 129, 129, 129, 129, 66}, // C
    {129, 129, 129,  129, 66, 0},
    {129, 129, 129,129,  66, 0, 0, 0},
    {129, 129, 129, 66, 0, 0, 0, 0},
    {129, 129, 66, 0, 0, 0, 0, 0},
    {129, 66, 0, 0, 0, 0, 0, 0},
    {66, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {254, 17, 17, 17, 17, 17, 254}, // A
    {17, 17, 17, 17, 17, 254, 0},
    {17, 17, 17, 17, 254, 0, 0, 0},
    {17, 17, 17, 254, 0, 0, 0, 0},
    {17, 17, 254, 0, 0, 0, 0, 0},
    {17, 254, 0, 0, 0, 0, 0, 0},
    {254, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {255, 2, 4, 8, 4, 2, 255, 0}, // M
    {2, 4, 8, 4, 2, 255, 0, 0},
    {4, 8, 4, 2, 255, 0, 0, 0},
    {8, 4, 2, 255, 0, 0, 0, 0},
    {4, 2, 255, 0, 0, 0, 0, 0},
    {2, 255, 0, 0, 0, 0, 0, 0},
    {255, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {255, 145, 145, 145, 145, 145, 98, 0}, // E
    {145, 145, 145, 145, 145, 145, 98, 0},
    {145, 145, 145, 145, 145, 98, 0, 0},
    {145, 145, 145, 145, 98, 0, 0, 0},
    {145, 145, 145, 98, 0, 0, 0, 0},
    {145, 145, 98, 0, 0, 0, 0, 0},
    {145, 98, 0, 0, 0, 0, 0, 0},
    {98, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

	{255, 9, 9, 9, 57, 255, 199, 0},//R
    {9, 9, 9, 57, 255, 199, 0, 0},
    {9, 9, 57, 255, 199, 0, 0, 0},
    {9, 57, 255, 199, 0, 0, 0, 0},
    {57, 255, 199, 0, 0, 0, 0, 0},
    {255, 199, 0, 0, 0, 0, 0, 0},
    {199, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {254, 17, 17, 17, 17, 17, 254}, // A
    {17, 17, 17, 17, 17, 254, 0},
    {17, 17, 17, 17, 254, 0, 0, 0},
    {17, 17, 17, 254, 0, 0, 0, 0},
    {17, 17, 254, 0, 0, 0, 0, 0},
    {17, 254, 0, 0, 0, 0, 0, 0},
    {254, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {78, 145, 145, 145, 145, 145, 98, 0}, // S
    {145, 145, 145, 145, 145, 98, 0, 0},
    {145, 145, 145, 145, 98, 0, 0, 0},
    {145, 145, 145, 98, 0, 0, 0, 0},
    {145, 145, 98, 0, 0, 0, 0, 0},
    {145, 98, 0, 0, 0, 0, 0, 0},
    {98, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {0, 65, 34, 20, 8, 4, 2, 1}, // Y
    {65, 34, 20, 8, 4, 2, 1, 0},
    {34, 20, 8, 4, 2, 1, 0, 0},
    {20, 8, 4, 2, 1, 0, 0, 0},
    {8, 4, 2, 1, 0, 0, 0, 0},
    {4, 2, 1, 0, 0, 0, 0, 0},
    {2, 1, 0, 0, 0, 0, 0, 0},
    {1, 0, 0, 0, 0, 0, 0, 0},

    {78, 145, 145, 145, 145, 145, 98, 0}, // S
    {145, 145, 145, 145, 145, 98, 0, 0},
    {145, 145, 145, 145, 98, 0, 0, 0},
    {145, 145, 145, 98, 0, 0, 0, 0},
    {145, 145, 98, 0, 0, 0, 0, 0},
    {145, 98, 0, 0, 0, 0, 0, 0},
    {98, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {1, 1, 1, 255, 1, 1, 1, 0}, // T
    {1, 1, 255, 1, 1, 1, 0, 0},
    {1, 255, 1, 1, 1, 0, 0, 0},
    {255, 1, 1, 1, 0, 0, 0, 0},
    {1, 1, 1, 0, 0, 0, 0, 0},
    {1, 1, 0, 0, 0, 0, 0, 0},
    {1, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0},

    {255, 145, 145, 145, 145, 145, 145, 145}, // E
    {145, 145, 145, 145, 145, 145, 145, 0},
    {145, 145, 145, 145, 145, 145, 0, 0},
    {145, 145, 145, 145, 145, 0, 0, 0},
    {145, 145, 145, 145, 0, 0, 0, 0},
    {145, 145, 145, 0, 0, 0, 0, 0},
    {145, 145, 0, 0, 0, 0, 0, 0},
    {145, 0, 0, 0, 0, 0, 0, 0},

	{255, 2, 4, 8, 4, 2, 255, 0},//M
	    {2, 4, 8, 4, 2, 255, 0, 0},
	    {4, 8, 4, 2, 255, 0, 0, 0},
	    {8, 4, 2, 255, 0, 0, 0, 0},
	    {4, 2, 255, 0, 0, 0, 0, 0},
	    {2, 255, 0, 0, 0, 0, 0, 0},
	    {255, 0, 0, 0, 0, 0, 0, 0},
	    {0, 0, 0,0,0,0,0,0},

};
/***********************************************************/
void main(void)
{
SYSTEM_INIT();
PINS_Config();
USART_Config();
BUTTONS_Config();

	while(1){
		MGPIO_voidGetPinValue(GPIO_PORTA, GPIO_PIN14, &mainDoorStatus);
		if(mainDoorStatus == 0){
			MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN8,GPIO_PIN_HIGH);
			MUSART_voidTransmit(MUSART_USART1,(u8*)"a",1);

		}
		else{
			MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN8,GPIO_PIN_LOW);

		}


		MGPIO_voidGetPinValue(GPIO_PORTA, GPIO_PIN15, &cameraSystemStatus);
		if(cameraSystemStatus == 0){
			MGPIO_voidSetPinValue(GPIO_PORTB,GPIO_PIN3,GPIO_PIN_HIGH);
			MUSART_voidTransmit(MUSART_USART1,(u8*)"b",1);


		}
		else{
			MGPIO_voidSetPinValue(GPIO_PORTB,GPIO_PIN3,GPIO_PIN_LOW);

		}


		MGPIO_voidGetPinValue(GPIO_PORTB, GPIO_PIN12, &garageDoorStatus);
		if(garageDoorStatus == 0){
			MGPIO_voidSetPinValue(GPIO_PORTC,GPIO_PIN13,GPIO_PIN_HIGH);
			MUSART_voidTransmit(MUSART_USART1,(u8*)"c",1);


		}
		else{
			MGPIO_voidSetPinValue(GPIO_PORTC,GPIO_PIN13,GPIO_PIN_LOW);

		}



	}
}



/************************FUNCTIONS PROTOTYPING*****************/

void handler_USART(void)
{
	MUSART_voidReceive(MUSART_USART1 ,&Global_u8RX);
	if(Global_u8RX == 'a'){
		HLEDMATRIX_voidInit();
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN13,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN12,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN11,GPIO_PIN_HIGH);

        for(int i = 0 ; i < SIZE ; i++) {
            HLEDMATRIX_voidDisplay(Main[i]);
            MSTK_voidDelayms(100);
        }

		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN11,GPIO_PIN_LOW);

	}

	if(Global_u8RX == 'b'){
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN11,GPIO_PIN_LOW);
	}
	if(Global_u8RX == 'c'){
		HLEDMATRIX_voidInit();
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN13,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN12,GPIO_PIN_HIGH);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN11,GPIO_PIN_LOW);

		// Display text on LED matrix
        for(int i = 0 ; i < SIZE_CAM ; i++) {
            HLEDMATRIX_voidDisplay(Cam[i]);
            MSTK_voidDelayms(100);
	}
        MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN12,GPIO_PIN_LOW);

	}
	if(Global_u8RX == 'd'){
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN12,GPIO_PIN_LOW);
	}
	if(Global_u8RX == 'e'){
		HLEDMATRIX_voidInit();
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN13,GPIO_PIN_HIGH);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN12,GPIO_PIN_LOW);
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN11,GPIO_PIN_LOW);

        for(int i = 0 ; i < SIZE_GAR ; i++) {
            HLEDMATRIX_voidDisplay(Garage[i]);
            MSTK_voidDelayms(100);
        }
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN13,GPIO_PIN_LOW);

	}

	if(Global_u8RX == 'f'){
		MGPIO_voidSetPinValue(GPIO_PORTA,GPIO_PIN13,GPIO_PIN_LOW);
	}

}


void SYSTEM_INIT(void){
	/*Initialize RCC module*/
	MRCC_voidInit();

	/*Enable clock to GPIOA*/
	MRCC_voidEnablePeripheral(RCC_AHB1,RCC_AHB1_GPIOA);
	MRCC_voidEnablePeripheral(RCC_AHB1,RCC_AHB1_GPIOB);
	MRCC_voidEnablePeripheral(RCC_AHB1,RCC_AHB1_GPIOC);


	/*Enable clock to USART1*/
	MRCC_voidEnablePeripheral(RCC_APB2,RCC_APB2_USART1);

	HLEDMATRIX_voidInit();

}
void PINS_Config(void){
	/*Configure Pins 9 & 10 as alternative function -> USART1*/
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN9,GPIO_ALT_FUNC);
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN10,GPIO_ALT_FUNC);

	/*Setup the pins of the alternative functions*/
	MGPIO_voidSetAltFunction(GPIO_PORTA,GPIO_PIN9,0b0111);
	MGPIO_voidSetAltFunction(GPIO_PORTA,GPIO_PIN10,0b0111);

	/*Configure pin0 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN11,GPIO_OUTPUT);

	/*Setup pin0 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTA,GPIO_PIN11,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);

	/*Configure pin1 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN12,GPIO_OUTPUT);

	/*Setup pin1 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTA,GPIO_PIN12,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);

	/*Configure pin0 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN13,GPIO_OUTPUT);

	/*Setup pin0 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTA,GPIO_PIN13,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);


	/*Configure pin0 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTA,GPIO_PIN8,GPIO_OUTPUT);

	/*Setup pin0 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTA,GPIO_PIN8,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);


	/*Configure pin0 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTB,GPIO_PIN3,GPIO_OUTPUT);

	/*Setup pin0 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTB,GPIO_PIN3,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);


	/*Configure pin0 as output*/
	MGPIO_voidSetPinMode(GPIO_PORTC,GPIO_PIN13,GPIO_OUTPUT);

	/*Setup pin0 with the suitable setting*/
	MGPIO_voidSetPinOutputMode(GPIO_PORTC,GPIO_PIN13,GPIO_PUSH_PULL,GPIO_MEDIUM_SPEED);

}

void USART_Config(void){
	/*Enable Peripheral number of USART1*/
	MNVIC_voidEnablePeripheralInterrupt(37);

	/*callBack function when the interrupt fires goes to*/
	MSUART_voidSetCallBack(handler_USART);


	MUSART_voidInit();
	MUSART_EnableUSART(MUSART_USART1);


}

void BUTTONS_Config(void){
	// ON/OFF Buttons Configuration
	MGPIO_voidSetPinMode(GPIO_PORTA , GPIO_PIN14 , GPIO_INPUT);
	MGPIO_voidSetPinInputMode(GPIO_PORTA , GPIO_PIN14 , GPIO_PULLUP);
	MGPIO_voidSetPinMode(GPIO_PORTA , GPIO_PIN15 , GPIO_INPUT);
	MGPIO_voidSetPinInputMode(GPIO_PORTA , GPIO_PIN15 , GPIO_PULLUP);
	MGPIO_voidSetPinMode(GPIO_PORTB , GPIO_PIN12 , GPIO_INPUT);
	MGPIO_voidSetPinInputMode(GPIO_PORTB , GPIO_PIN12 , GPIO_PULLUP);

}
